﻿using BUSINESS_LOGIC.Business_Logic;
using IBUSINESS_LOGIC.IBusiness_Logic;
using Microsoft.Extensions.DependencyInjection;

namespace BUSINESS_LOGIC
{
    public static class ServiceRegistration
    {
        public static void AddInfrastructure(this IServiceCollection service)
        {
            service.AddTransient<IUnitOfWork, UnitOfWork>();
            service.AddTransient<ICrudMasters,CrudMasters>();
        }
    }
}
