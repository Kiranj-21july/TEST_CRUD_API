﻿using IBUSINESS_LOGIC.IBusiness_Logic;

namespace BUSINESS_LOGIC.Business_Logic
{
    public class UnitOfWork : IUnitOfWork
    {
        public UnitOfWork(ICrudMasters _Masters_Repo) {
            crudMasters = _Masters_Repo;
        }
        public ICrudMasters crudMasters { get;}

    }
}
