﻿using IBUSINESS_LOGIC.IBusiness_Logic;
using MODEL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Dapper;

namespace BUSINESS_LOGIC.Business_Logic
{
    public class CrudMasters : ICrudMasters
    {
        private readonly IConfiguration configuration;

        public CrudMasters(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        public async Task<IReadOnlyList<Crud_Model>> GetAllAsync()
        {
            try
            {
                string procedure = "sp_Category_Master_crud";
                using (var connection = new SqlConnection(configuration.GetConnectionString("DefaultConnection")))
                {
                    var parameters = new
                    {
                        Action = 1
                    };
                    return (await connection.QueryAsync<Crud_Model>(procedure, parameters, commandType: CommandType.StoredProcedure).ConfigureAwait(false)).AsList();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<RETURN_MESSAGE> AddAsync(Crud_Model entity)
        {
            try
            {
                string procedure = "sp_Category_Master_crud";
                using (var connection = new SqlConnection(configuration.GetConnectionString("DefaultConnection")))
                {
                    var parameters = new
                    {
                        Action = 2,
                        category_name = entity.category_name,                     
                    };
                    return (await connection.QueryAsync<RETURN_MESSAGE>(procedure, parameters, commandType: CommandType.StoredProcedure).ConfigureAwait(false)).SingleOrDefault()!;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<RETURN_MESSAGE> DeleteAsync(Crud_Model entity)
        {
            try
            {
                string procedure = "sp_Category_Master_crud";
                using (var connection = new SqlConnection(configuration.GetConnectionString("DefaultConnection")))
                {
                    var parameters = new
                    {
                        Action = 5,
                        category_id = entity.category_id,
                    };

                    return (await connection.QueryAsync<RETURN_MESSAGE>(procedure, parameters, commandType: CommandType.StoredProcedure).ConfigureAwait(false)).SingleOrDefault()!;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<Crud_Model> GetByIdAsync(Crud_Model entity)
        {
            try
            {
                string procedure = "sp_Category_Master_crud";
                using (var connection = new SqlConnection(configuration.GetConnectionString("DefaultConnection")))
                {
                    var parameters = new
                    {
                        Action = 4,
                        category_id = entity.category_id,
                    };

                    return (await connection.QueryAsync<Crud_Model>(procedure, parameters, commandType: CommandType.StoredProcedure).ConfigureAwait(false)).SingleOrDefault()!;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<RETURN_MESSAGE> UpdateAsync(Crud_Model entity)
        {
            try
            {
                string procedure = "sp_Category_Master_crud";
                using (var connection = new SqlConnection(configuration.GetConnectionString("DefaultConnection")))
                {
                    var parameters = new
                    {
                        Action = 3,
                        category_id = entity.category_id,
                        category_name = entity.category_name,
                    };

                    return (await connection.QueryAsync<RETURN_MESSAGE>(procedure, parameters, commandType: CommandType.StoredProcedure).ConfigureAwait(false)).SingleOrDefault()!;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
