﻿namespace MODEL
{
    public class Crud_Model
    {
        public string? Action { get; set; }
        public string? category_id { get; set; }
        public string? category_name { get; set; }
        public string? unique_id { get; set; }
        public string? status { get; set; }
        public string? is_active { get; set; }
        public string? createddate { get; set; }
        public string? updateddate { get; set; }
    }

    public class RETURN_MESSAGE
    {
        public string? STATUS_CODE { get; set; }
        public bool? STATUS { get; set; }
        public string? MESSAGE { get; set; }
    }
}
