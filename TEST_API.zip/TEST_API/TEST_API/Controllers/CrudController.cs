﻿using IBUSINESS_LOGIC.IBusiness_Logic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MODEL;

namespace TEST_API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CrudController : ControllerBase
    {
        private readonly IUnitOfWork unitOfWork;
        private IWebHostEnvironment hostEnvironment;
        public CrudController(IUnitOfWork unitOfWork, IWebHostEnvironment environment)
        {
            this.unitOfWork = unitOfWork;
            hostEnvironment = environment;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllAsync()
        {
            var data = await unitOfWork.crudMasters.GetAllAsync();
            if (data.Count > 0)
            {
                var b = new
                {
                    GetAllData = data,
                    MESSAGE = "Success",
                    STATUS = true,
                    STATUS_CODE = "200"
                };
                return Ok(b);
            }
            else
            {
                RETURN_MESSAGE rETURN_MESSAGE = new RETURN_MESSAGE()
                {
                    STATUS_CODE = "404",
                    MESSAGE = "No Records Found",
                    STATUS = false,
                };
                return Ok(rETURN_MESSAGE);

            }
        }

        [HttpPost]
        public async Task<IActionResult> Add_Category(Crud_Model entity)
        {
            if (entity == null)
            {
                var b = new
                {
                    MESSAGE = "INVALID JSON",
                    STATUS = false
                };
                return Ok(b);
            }
            else
            {
                var data = await unitOfWork.crudMasters.AddAsync(entity);
                if (data != null)
                {
                    var b = new
                    {
                        MESSAGE = "Success",
                        STATUS = true
                    };
                    return Ok(b);
                }
                else
                {
                    RETURN_MESSAGE errormessage = new RETURN_MESSAGE()
                    {
                        MESSAGE = "No Records Found",
                        STATUS = false
                    };

                    return Ok(errormessage);
                }

            }

        }

        [HttpPost]
        public async Task<IActionResult> Category_Update(Crud_Model entity)
        {
            if (entity == null)
            {
                var b = new
                {
                    MESSAGE = "INVALID JSON",
                    STATUS = false
                };
                return Ok(b);
            }
            else
            {
                var data = await unitOfWork.crudMasters.UpdateAsync(entity);
                if (data != null)
                {
                    var b = new
                    {
                        MESSAGE = "Success",
                        STATUS = true
                    };
                    return Ok(b);
                }
                else
                {
                    RETURN_MESSAGE errormessage = new RETURN_MESSAGE()
                    {
                        MESSAGE = "No Records Found",
                        STATUS = false
                    };

                    return Ok(errormessage);
                }

            }

        }

        [HttpPost]
        public async Task<IActionResult> Category_GetById(Crud_Model entity)
        {
            var data = await unitOfWork.crudMasters.GetByIdAsync(entity);
            if (data != null)
            {
                var b = new
                {
                    Get_byId = data,
                    MESSAGE = "Success",
                    STATUS = true,
                    STATUS_CODE = "200"

                };
                return Ok(b);
            }
            else
            {
                RETURN_MESSAGE errormessage = new RETURN_MESSAGE()
                {
                    MESSAGE = "No Records Found",
                    STATUS = false,
                    STATUS_CODE = "404"
                };

                return Ok(errormessage);
            }

        }

        [HttpPost]
        public async Task<IActionResult> Category_Delete(Crud_Model entity)
        {
            if (entity == null)
            {
                var b = new
                {
                    MESSAGE = "INVALID JSON",
                    STATUS = false
                };
                return Ok(b);
            }
            else
            {
                var data = await unitOfWork.crudMasters.DeleteAsync(entity);
                if (data != null)
                {
                    var b = new
                    {
                        MESSAGE = "Success",
                        STATUS = true
                    };
                    return Ok(b);
                }
                else
                {
                    RETURN_MESSAGE errormessage = new RETURN_MESSAGE()
                    {
                        MESSAGE = "No Records Found",
                        STATUS = false
                    };

                    return Ok(errormessage);
                }

            }

        }
    }
}
