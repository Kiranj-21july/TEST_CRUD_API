﻿namespace IBUSINESS_LOGIC
{
    public class Class1
    {

    }
}
