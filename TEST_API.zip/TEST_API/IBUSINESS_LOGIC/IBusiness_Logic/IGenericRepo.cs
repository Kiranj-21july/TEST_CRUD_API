﻿using MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IBUSINESS_LOGIC.IBusiness_Logic
{
    public interface IGenericRepo<T> where T : class
    {
        Task<T> GetByIdAsync(T entity);
        Task<IReadOnlyList<T>> GetAllAsync();
        Task<RETURN_MESSAGE> AddAsync(T entity);
        Task<RETURN_MESSAGE> UpdateAsync(T entity);
        Task<RETURN_MESSAGE> DeleteAsync(T entity);

    }
}
