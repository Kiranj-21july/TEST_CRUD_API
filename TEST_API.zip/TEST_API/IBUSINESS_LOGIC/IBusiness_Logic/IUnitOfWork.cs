﻿
namespace IBUSINESS_LOGIC.IBusiness_Logic
{
    public interface IUnitOfWork
    {
        ICrudMasters crudMasters { get; }
    }
}
